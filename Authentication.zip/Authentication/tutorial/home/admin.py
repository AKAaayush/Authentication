from django.contrib import admin
from home.models import Friend,Post

# Register your models here.
admin.site.register(Friend)
admin.site.register(Post)